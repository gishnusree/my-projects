# basic-verification-projects
SystemVerilog and UVM beginner projects — 4-bit Adder and 2:1 MUX verification
